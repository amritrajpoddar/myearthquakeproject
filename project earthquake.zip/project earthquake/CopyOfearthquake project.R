*Get necessary libraries:*
  ```{r Libraries, message=FALSE}
library(datasets)
library(scatterplot3d)
# library(rgl)
# library(Rcmdr)
```

*Summarize the data:*
  ```{r Summary, results='hide'}
sapply(attenu, data.class)
summary(attenu)
```

*Make plots to understand variation of accel:*
  ```{r Plots, fig.width=9, fig.height=6}
attach(attenu)
par(mfrow=c(1,3))
plot(accel~dist, main="accel vs dist")
plot(accel~mag, data=attenu, main="accel vs mag")
scatterplot3d(dist, mag, accel, pch=16, highlight.3d=TRUE, type="h", main="accel vs dist & mag")
# plot3d(dist, mag, accel,  col="red", size=5)
# scatter3d(dist, mag, accel,  col="red", size=5)
```

The plots indicate that accel is linear in inv square dist and gaussian around 6.5 mag.

*Introduce new variables:*
  ```{r Variables}
attenu$distisq <- 1/(attenu$dist*attenu$dist)
attenu$maggau <- 1/(exp((attenu$mag-6.5)*(attenu$mag-6.5)))
```

*Do separate linear regressions to compute indicative coefficients:*
  ```{r Regression}
summary(lm(accel~dist, data=attenu))$coefficients
summary(lm(accel~distisq, data=attenu))$coefficients
summary(lm(accel~mag, data=attenu))$coefficients
summary(lm(accel~maggau, data=attenu))$coefficients
```

High tau values indicate that accel is linear in inv square dist and gaussian around 6.5 mag.

*Do combined linear regression with selected variables:*
  ```{r Combined}
coef <- summary(lm(accel~distisq+maggau, data=attenu))$coefficients
coef
```

Low p values indicate that selected independent variables are reasonable.

*Formula derived from this analysis:*
  ```{r Formula}
print(paste("accel =", round(coef[1,1],digits=4), "+ (", round(coef[2,1],digits=4), "/(dist^2)) + (", round(coef[3,1],digits=4), "/exp((mag-6.5)^2))"))
```

